# prediction 外部预测实验

对无标签预测集 `dataset/prediction/Additional file 7.csv`（PubChem 导出，8878 条）
运行已训练好的模型，产出各基模型、多数投票与 SpecEn-Moll 的预测结果，并在无真值标签的
条件下给出可解释的可靠性诊断。

- 实验脚本：仓库根目录 `prediction_experiment.py`
- 运行方式：`python prediction_experiment.py`（`--limit N` 可小规模试跑）
- 产出目录：本目录 `results/prediction/`

---

## 1. 与训练过程的对齐

训练期的预处理链路在 `utils/data_preprocessing.preprocess()`：

```
dataset/train/text_feature.xlsx (182 条) + dataset/test/text_feature.xlsx (78 条)
  + 谱嵌入 feature_0 / feature_1                    -> 232 列
  dropna()
  LabelEncoder 编码 13 个 object 列（拟合在 train 上）
  StandardScaler 只 fit 在 dataset/train 的【文本部分】，图特征不缩放
      RF / XGB   -> 未缩放的特征（带列名的 DataFrame）
      SVM / LR / KNN -> 缩放后的特征（numpy）
```

本脚本对预测集复刻同一套变换。有两处**必须**与 `preprocess_1()` 区分开，
否则特征与训练期错位、预测结果不可信：

| 项 | `preprocess_1()` 的做法 | 本脚本的做法 |
|---|---|---|
| StandardScaler | 在**待预测集自身**上重新 fit | 从训练表**复现**训练期的 scaler，只做 transform |
| LabelEncoder | 在待预测集自身上重新 fit，按新的类别字典排序 | 复用训练期的类别→编码映射，训练中未出现过的类别统一记为哨兵值 `-1` |

训练期的 scaler 在 `dataset/train/text_feature.xlsx`（182 条）上拟合。
`model_cols` 直接从该训练表的列名推导（去掉 `lable`），
保证 230 列的**顺序**与训练期完全一致；拼上 `feature_0/feature_1` 后为 232 维，
与 5 个模型的 `n_features_in_` 一致。

## 2. 数据处理流程

| 步骤 | 动作 | 产物 |
|---|---|---|
| step1 | 读 CSV，RDKit 解析 SMILES，丢弃 4 条无法解析的（超价溴 `Br=C`），按 SMILES 去重 | `intermediate/prediction_smiles.xlsx` |
| step2 | 用 RDKit 复算 217 个描述符 + 8 个指纹，与训练表同构 | `intermediate/prediction_text_feature.xlsx`（230 列） |
| step3 | `utils/pc_gnn.get_pc_gnn_1` 生成 PyG 分子图 → `utils/spectral_embedding.get_embedding` 做谱嵌入 | `intermediate/prediction_pc-gnn.pt`、`feature_0/feature_1` |
| step4 | 复现训练期 scaler / LabelEncoder，拼装 232 维特征矩阵 | 内存对象 |
| step5 | 载入 `theta/specen_moll/` 下 5 个基模型 + 投票 + SpecEn-Moll 预测 | 各预测表 |
| step6 | 适用域 / 类别列未命中率 / 模型间一致性诊断 | `diagnostics/` |

> step1 丢弃非法 SMILES 是必需的：`get_pc_gnn_1` 遇到解析失败会 `continue`
> 而不追加分子图，若不在此提前剔除，后续**所有**分子的图与 SMILES 会整体错位。

## 3. 产出结构

```
results/prediction/
├── prediction.xlsx                    主结果表：5 基模型 + VOTING + SpecEn-Moll 的预测与概率
├── base_models/{RF,SVM,XGB,LR,KNN}/prediction.xlsx
├── ensemble/voting/prediction.xlsx
├── ensemble/SpecEn-Moll/prediction.xlsx
├── intermediate/                  中间数据集
│   ├── prediction_smiles.xlsx
│   ├── prediction_text_feature.xlsx
│   └── prediction_pc-gnn.pt
├── diagnostics/
│   ├── applicability_domain.csv   每个数值描述符的越界率
│   ├── model_agreement.csv        每个化合物的基模型投票明细
│   └── summary.json               汇总指标
└── run.log                        运行日志
```

## 4. 无标签条件下能做什么

没有真值标签就无法算 accuracy/F1，但可以测三件事，它们共同决定了预测结果的
可信区间：

1. **适用域（applicability domain）**——多少分子的描述符落在训练集范围内。
   越界越多，模型的预测越不可信。用「训练集内部 30% 留出相对 70% 训练集」的
   越界率作为基准。
2. **类别列未命中率**——13 个 object 列（SMILES、InChI、指纹等）有多少取值在
   训练集中从未出现过。这些列在预测集上退化为常数，模型从中学到的判别力无法迁移。
3. **模型间一致性**——5 个基模型彼此的分歧程度。分歧大说明预测不可靠；
   票数极端集中则要警惕模型塌缩到单一类别。

## 5. 实验结果

全量 8878 条，运行耗时约 2.5 分钟（21:56:46 → 21:59:09）。

### 5.1 样本流转

| 阶段 | 行数 | 说明 |
|---|---|---|
| 原始 CSV | 8878 | PubChem 导出，8878 个唯一 SMILES / CID |
| RDKit 可解析 | 8874 | 丢弃 4 条超价溴 `Br=C`（行 7090 / 7105 / 7186 / 7195） |
| `dropna()` 后 | 8871 | 3 条因 RDKit 的 `Max/MinPartialCharge`、`BCUT2D_*` 描述符返回 NaN 被丢弃 |
| **最终预测** | **8871** | 与训练集零重叠 |

### 5.2 预测结果

| 方法 | 阳性率 | 阳性数 | 备注 |
|---|---|---|---|
| RF | 72.28% | 6412 | 概率近乎常数（均值 0.551，标准差 0.072，四分位 0.50/0.55/0.60） |
| SVM | 99.94% | 8866 | 塌缩为几乎全阳 |
| XGB | 100.00% | 8871 | 塌缩为全阳 |
| LR | 99.93% | 8865 | 塌缩为几乎全阳 |
| KNN | 67.06% | 5949 | 唯一还保有区分度的模型（概率标准差 0.247） |
| **VOTING**（≥4 票） | **81.92%** | 7265 | 实质等价于 `RF ∨ KNN` |
| **SpecEn-Moll** | **99.04%** | 8786 | 与 VOTING 一致率 82.6% |

投票分布：2 票 2 条、3 票 1602 条、4 票 2182 条、5 票 5085 条。
**没有任何一行出现 0 票或 1 票**，也没有任何一行 5 个模型同时判为阴性。

### 5.3 无标签诊断

**适用域——数值部分其实是好的：**

- 217 个数值描述符的越界取值占比 **0.17%**
- 训练集内部 30% 留出对 70% 训练的基准越界率为 **0.52%**
- 预测集的越界率**低于**训练集自身的留出基准，说明预测集在**数值描述符上落在训练分布之内**
- 25.4% 的分子至少含 1 个越界描述符；越界最多的几个是
  `FpDensityMorgan3`(4.69%)、`MinEStateIndex`(3.37%)、`SMR_VSA3`(2.85%)、
  `VSA_EState4`(1.72%)、`VSA_EState5`(1.66%)

**类别列——全部失效：**

- 13 个 object 列 × 8871 行 = 115,323 个单元格，其中 **115,026 个（99.74%）**
  在训练集中从未出现过，全部映射到哨兵值 `-1`
- 也就是说这 13 列在预测集上退化为常数，模型在训练期从中学到的判别力**无法迁移**

**模型间一致性：**

- 5 个基模型完全一致的比例 57.3%，但这个「一致」是**全体一致判为阳性**（5085 条），
  不是一致判为阴性——没有一条是 5 个模型同时判负
- SVM / XGB / LR 在 8860 / 8871 条上同时为阳性

### 5.4 结论

1. **描述符部分没有分布漂移**。越界率 0.17% 低于训练集内部留出基准 0.52%，
   说明这批 PubChem 化合物在理化性质上与训练集是同分布的，预测集本身是合法的。

2. **预测结果不可信，原因是模型而不是数据**。训练集阳性率 44.3%（146 负 / 116 正，
   基本均衡），而预测集上 5 个模型的阳性率是 67%–100%，聚合后 82%–99%。
   SVM/XGB/LR 塌缩为全阳、RF 的概率分布近乎常数、5 个模型没有任何一条同时判负，
   这是典型的**判别力塌缩**：模型退化成「恒判阳性」。

3. **根因是那 13 个类别列**。它们占训练期特征空间的绝大部分取值维度，模型（尤其
   RF / XGB）高度依赖其中的 `Mol`（Excel 序列化的 RDKit 内存地址字符串）与指纹列。
   在预测集上 99.74% 的取值未出现过，模型拿不到判别信号，只剩数值描述符这一条腿，
   于是退化为常数偏置。

4. **两种聚合方法都没有起到纠偏作用**。VOTING 在 SVM/XGB/LR 全阳的情况下等价于
   `RF ∨ KNN`，被 KNN 拉着走；SpecEn-Moll 作为 stacking 网络学到了同样的塌缩模式，
   阳性率高达 99.04%，比投票还高。**在这批数据上 SpecEn-Moll 比 VOTING 更不可信。**

5. **可用的部分**：KNN 概率分布标准差 0.247、RF 概率区间 0.30–0.91，
   两者都还有连续信号。18.03%（1599 条）的分子是 RF 与 KNN 同时判负，
   这是全集中**唯一有跨模型一致反对证据**的子集；若要从中筛出值得优先复核的
   候选，应以这批为主，而不是以投票/SpecEn-Moll 的结果为准。

6. **后续建议**（未实施，按要求不改动训练与推理代码）：把 13 个类别列从特征中剔除、
   对 `Ipc` 做量级截断、重新训练并持久化 scaler/encoder；再以训练集内部留出做
   基准，检查预测集上的阳性率是否回落到 44% 附近。

